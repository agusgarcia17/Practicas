Maquetar las dos pantallas que se muestran en cumpleWebVistas.

En la home a partir de la manipulaci�n de la fecha de hoy,
mostrar la informaci�n del cumplea�os del d�a. 

Ayuda:

