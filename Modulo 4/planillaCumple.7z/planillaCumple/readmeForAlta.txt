Maquetar las dos pantallas que se muestran en cumpleWebVistas.

Las im�genes pueden ser las incluidas en recursos

Desarrollar la l�gica del formulario. 

- Utilizar un input Date, para simplificar el manejo de la fecha
- Ambos campos deben ser obligatorios
- Seleccionar una imagen haciendo click en ella
- Completar el input imagen seleccionada con el nombre de la imagen seleccionada
- Guardar toda la informaci�n del formulario

